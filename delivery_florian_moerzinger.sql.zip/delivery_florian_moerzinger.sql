-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Erstellungszeit: 08. Aug 2020 um 19:40
-- Server-Version: 10.4.13-MariaDB
-- PHP-Version: 7.4.8

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `delivery_florian_moerzinger`
--
CREATE DATABASE IF NOT EXISTS `delivery_florian_moerzinger` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `delivery_florian_moerzinger`;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `deliver_office`
--

CREATE TABLE `deliver_office` (
  `Id_Delivery_Office` int(11) NOT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `Tel_Number` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `deliver_office`
--

INSERT INTO `deliver_office` (`Id_Delivery_Office`, `Address`, `Tel_Number`) VALUES
(1, 'Backstein 34', 664001245),
(2, 'Backhausen 2', 676852147);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `district`
--

CREATE TABLE `district` (
  `Id_District` int(11) NOT NULL,
  `ZIP` int(5) DEFAULT NULL,
  `Name` varchar(50) DEFAULT NULL,
  `Fk_Postman` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `district`
--

INSERT INTO `district` (`Id_District`, `ZIP`, `Name`, `Fk_Postman`) VALUES
(1, 3652, 'Hinterwurzen', 1),
(2, 3640, 'Staubfresser', 2),
(3, 3670, 'Bergowe', 3);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `district_list`
--

CREATE TABLE `district_list` (
  `Id_District_List` int(11) NOT NULL,
  `Fk_Delivery_Office` int(11) DEFAULT NULL,
  `Fk_District` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `district_list`
--

INSERT INTO `district_list` (`Id_District_List`, `Fk_Delivery_Office`, `Fk_District`) VALUES
(1, 1, 3),
(2, 2, 2),
(3, 2, 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `incomming_mail`
--

CREATE TABLE `incomming_mail` (
  `Id_Incomming_Mail` int(11) NOT NULL,
  `Express_Delivery` tinyint(1) DEFAULT NULL,
  `Incomming_Date` date DEFAULT NULL,
  `Fk_Letter` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `incomming_mail`
--

INSERT INTO `incomming_mail` (`Id_Incomming_Mail`, `Express_Delivery`, `Incomming_Date`, `Fk_Letter`) VALUES
(1, 1, '2020-08-02', 1),
(2, 0, '2020-08-02', 2),
(3, 0, '2020-08-03', 3);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `letter_package`
--

CREATE TABLE `letter_package` (
  `Id_Letter_Package` int(11) NOT NULL,
  `Send_Date` date DEFAULT NULL,
  `Fk_Sender` int(11) DEFAULT NULL,
  `Fk_Recipient` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `letter_package`
--

INSERT INTO `letter_package` (`Id_Letter_Package`, `Send_Date`, `Fk_Sender`, `Fk_Recipient`) VALUES
(1, '2020-08-01', 1, 6),
(2, '2020-08-02', 2, 5),
(3, '2020-08-02', 5, 3);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `mailbox`
--

CREATE TABLE `mailbox` (
  `Id_Mailbox` int(11) NOT NULL,
  `Address` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `mailbox`
--

INSERT INTO `mailbox` (`Id_Mailbox`, `Address`) VALUES
(1, 'Große Gasse 34'),
(2, 'Kleine Gasse 24'),
(3, 'Keine Gasse 14');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `outcommig_mail`
--

CREATE TABLE `outcommig_mail` (
  `Id_Outcomming_Mail` int(11) NOT NULL,
  `Outcomming_Date` date DEFAULT NULL,
  `Fk_Letter` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `outcommig_mail`
--

INSERT INTO `outcommig_mail` (`Id_Outcomming_Mail`, `Outcomming_Date`, `Fk_Letter`) VALUES
(1, '2020-08-03', 1),
(2, '2020-08-06', 2),
(3, '2020-08-07', 3);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `people`
--

CREATE TABLE `people` (
  `Id_People` int(11) NOT NULL,
  `First_Name` varchar(20) DEFAULT NULL,
  `Last_Name` varchar(20) DEFAULT NULL,
  `ZIP` int(5) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `people`
--

INSERT INTO `people` (`Id_People`, `First_Name`, `Last_Name`, `ZIP`, `Address`) VALUES
(1, 'Herbert', 'Hobiger', 3652, 'Keller Gasse 34'),
(2, 'Anton', 'Fichtenhuber', 3652, 'Keller Gasse 2'),
(3, 'Engelbert', 'Fleichhauer', 3640, 'Stadtplatz 45'),
(4, 'Maria', 'Pfaffenbacher', 3640, 'Heustadelweg 33'),
(5, 'Gustl', 'Erwacht', 3670, 'Inder Gasse 4'),
(6, 'Meindl', 'Hattan', 3670, 'Farbstift 90');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `postman`
--

CREATE TABLE `postman` (
  `Id_Postman` int(11) NOT NULL,
  `Name` varchar(40) DEFAULT NULL,
  `Tel_Number` int(20) DEFAULT NULL,
  `Date_of_Birth` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `postman`
--

INSERT INTO `postman` (`Id_Postman`, `Name`, `Tel_Number`, `Date_of_Birth`) VALUES
(1, 'Herbert Hobiger', 650251463, '1970-12-21'),
(2, 'Ignatz Engelbert', 664794613, '1980-02-02'),
(3, 'Siegfried Enzel', 664718293, '1990-06-06');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `post_center`
--

CREATE TABLE `post_center` (
  `Id_Post_Center` int(11) NOT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `Tel_Number` int(20) DEFAULT NULL,
  `Country` varchar(30) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `post_center`
--

INSERT INTO `post_center` (`Id_Post_Center`, `Address`, `Tel_Number`, `Country`) VALUES
(1, 'Hauptstraße 1', 2147483647, 'Niederösterreich');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `post_center_delivery`
--

CREATE TABLE `post_center_delivery` (
  `Id_Post_Center_Delivery` int(11) NOT NULL,
  `Fk_Post_Center` int(11) DEFAULT NULL,
  `Fk_Post_Office` int(11) DEFAULT NULL,
  `Fk_Delivery_Office` int(11) DEFAULT NULL,
  `Fk_Letter` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `post_center_delivery`
--

INSERT INTO `post_center_delivery` (`Id_Post_Center_Delivery`, `Fk_Post_Center`, `Fk_Post_Office`, `Fk_Delivery_Office`, `Fk_Letter`) VALUES
(1, 1, 1, 2, 1),
(2, 1, 2, 1, 2),
(3, 1, 3, 1, 3);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `post_office`
--

CREATE TABLE `post_office` (
  `Id_Post_Office` int(11) NOT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `Tel_Number` int(20) DEFAULT NULL,
  `FK_Incomming_Mail` int(11) DEFAULT NULL,
  `Fk_Mailbox` int(11) DEFAULT NULL,
  `Fk_Post_Partner` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `post_office`
--

INSERT INTO `post_office` (`Id_Post_Office`, `Address`, `Tel_Number`, `FK_Incomming_Mail`, `Fk_Mailbox`, `Fk_Post_Partner`) VALUES
(1, 'Leise Gasse 12', 664781829, 1, 2, 2),
(2, 'Hintere Gasse 1', 664785974, 2, 1, 1),
(3, 'Graue Straße 34', 650461524, 3, 3, 3);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `post_partner`
--

CREATE TABLE `post_partner` (
  `Id_Post_Partner` int(11) NOT NULL,
  `Name` varchar(30) DEFAULT NULL,
  `Address` varchar(50) DEFAULT NULL,
  `Tel_Number` int(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `post_partner`
--

INSERT INTO `post_partner` (`Id_Post_Partner`, `Name`, `Address`, `Tel_Number`) VALUES
(1, 'Der Gerät', 'März Straße 2', 664102030),
(2, 'schneien Haare und Post', 'Ottakringer Straße 50', 650784512),
(3, 'Tankstelle Horst', 'OverseeStraße 140', 650326598);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `to_deliver`
--

CREATE TABLE `to_deliver` (
  `Id_To_Deliver` int(11) NOT NULL,
  `Fk_Outcomming_Mail` int(11) DEFAULT NULL,
  `Fk_Delivery_Office` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `to_deliver`
--

INSERT INTO `to_deliver` (`Id_To_Deliver`, `Fk_Outcomming_Mail`, `Fk_Delivery_Office`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 3, 2);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `deliver_office`
--
ALTER TABLE `deliver_office`
  ADD PRIMARY KEY (`Id_Delivery_Office`);

--
-- Indizes für die Tabelle `district`
--
ALTER TABLE `district`
  ADD PRIMARY KEY (`Id_District`),
  ADD KEY `Fk_Postman` (`Fk_Postman`);

--
-- Indizes für die Tabelle `district_list`
--
ALTER TABLE `district_list`
  ADD PRIMARY KEY (`Id_District_List`),
  ADD KEY `Fk_Delivery_Office` (`Fk_Delivery_Office`),
  ADD KEY `Fk_District` (`Fk_District`);

--
-- Indizes für die Tabelle `incomming_mail`
--
ALTER TABLE `incomming_mail`
  ADD PRIMARY KEY (`Id_Incomming_Mail`),
  ADD KEY `Fk_Letter` (`Fk_Letter`);

--
-- Indizes für die Tabelle `letter_package`
--
ALTER TABLE `letter_package`
  ADD PRIMARY KEY (`Id_Letter_Package`),
  ADD KEY `Fk_Sender` (`Fk_Sender`),
  ADD KEY `Fk_Recipient` (`Fk_Recipient`);

--
-- Indizes für die Tabelle `mailbox`
--
ALTER TABLE `mailbox`
  ADD PRIMARY KEY (`Id_Mailbox`);

--
-- Indizes für die Tabelle `outcommig_mail`
--
ALTER TABLE `outcommig_mail`
  ADD PRIMARY KEY (`Id_Outcomming_Mail`),
  ADD KEY `Fk_Letter` (`Fk_Letter`);

--
-- Indizes für die Tabelle `people`
--
ALTER TABLE `people`
  ADD PRIMARY KEY (`Id_People`);

--
-- Indizes für die Tabelle `postman`
--
ALTER TABLE `postman`
  ADD PRIMARY KEY (`Id_Postman`);

--
-- Indizes für die Tabelle `post_center`
--
ALTER TABLE `post_center`
  ADD PRIMARY KEY (`Id_Post_Center`);

--
-- Indizes für die Tabelle `post_center_delivery`
--
ALTER TABLE `post_center_delivery`
  ADD PRIMARY KEY (`Id_Post_Center_Delivery`),
  ADD KEY `Fk_Post_Center` (`Fk_Post_Center`),
  ADD KEY `Fk_Post_Office` (`Fk_Post_Office`),
  ADD KEY `Fk_Delivery_Office` (`Fk_Delivery_Office`),
  ADD KEY `Fk_Letter` (`Fk_Letter`);

--
-- Indizes für die Tabelle `post_office`
--
ALTER TABLE `post_office`
  ADD PRIMARY KEY (`Id_Post_Office`),
  ADD KEY `FK_Incomming_Mail` (`FK_Incomming_Mail`),
  ADD KEY `Fk_Mailbox` (`Fk_Mailbox`),
  ADD KEY `Fk_Post_Partner` (`Fk_Post_Partner`);

--
-- Indizes für die Tabelle `post_partner`
--
ALTER TABLE `post_partner`
  ADD PRIMARY KEY (`Id_Post_Partner`);

--
-- Indizes für die Tabelle `to_deliver`
--
ALTER TABLE `to_deliver`
  ADD PRIMARY KEY (`Id_To_Deliver`),
  ADD KEY `Fk_Outcomming_Mail` (`Fk_Outcomming_Mail`),
  ADD KEY `Fk_Delivery_Office` (`Fk_Delivery_Office`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `deliver_office`
--
ALTER TABLE `deliver_office`
  MODIFY `Id_Delivery_Office` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT für Tabelle `district`
--
ALTER TABLE `district`
  MODIFY `Id_District` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `district_list`
--
ALTER TABLE `district_list`
  MODIFY `Id_District_List` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `incomming_mail`
--
ALTER TABLE `incomming_mail`
  MODIFY `Id_Incomming_Mail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `letter_package`
--
ALTER TABLE `letter_package`
  MODIFY `Id_Letter_Package` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `mailbox`
--
ALTER TABLE `mailbox`
  MODIFY `Id_Mailbox` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `outcommig_mail`
--
ALTER TABLE `outcommig_mail`
  MODIFY `Id_Outcomming_Mail` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `people`
--
ALTER TABLE `people`
  MODIFY `Id_People` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT für Tabelle `postman`
--
ALTER TABLE `postman`
  MODIFY `Id_Postman` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `post_center`
--
ALTER TABLE `post_center`
  MODIFY `Id_Post_Center` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT für Tabelle `post_center_delivery`
--
ALTER TABLE `post_center_delivery`
  MODIFY `Id_Post_Center_Delivery` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `post_office`
--
ALTER TABLE `post_office`
  MODIFY `Id_Post_Office` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `post_partner`
--
ALTER TABLE `post_partner`
  MODIFY `Id_Post_Partner` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT für Tabelle `to_deliver`
--
ALTER TABLE `to_deliver`
  MODIFY `Id_To_Deliver` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- Constraints der exportierten Tabellen
--

--
-- Constraints der Tabelle `district`
--
ALTER TABLE `district`
  ADD CONSTRAINT `district_ibfk_1` FOREIGN KEY (`Fk_Postman`) REFERENCES `postman` (`Id_Postman`);

--
-- Constraints der Tabelle `district_list`
--
ALTER TABLE `district_list`
  ADD CONSTRAINT `district_list_ibfk_1` FOREIGN KEY (`Fk_Delivery_Office`) REFERENCES `deliver_office` (`Id_Delivery_Office`),
  ADD CONSTRAINT `district_list_ibfk_2` FOREIGN KEY (`Fk_District`) REFERENCES `district` (`Id_District`);

--
-- Constraints der Tabelle `incomming_mail`
--
ALTER TABLE `incomming_mail`
  ADD CONSTRAINT `incomming_mail_ibfk_1` FOREIGN KEY (`Fk_Letter`) REFERENCES `letter_package` (`Id_Letter_Package`);

--
-- Constraints der Tabelle `letter_package`
--
ALTER TABLE `letter_package`
  ADD CONSTRAINT `letter_package_ibfk_1` FOREIGN KEY (`Fk_Sender`) REFERENCES `people` (`Id_People`),
  ADD CONSTRAINT `letter_package_ibfk_2` FOREIGN KEY (`Fk_Recipient`) REFERENCES `people` (`Id_People`);

--
-- Constraints der Tabelle `outcommig_mail`
--
ALTER TABLE `outcommig_mail`
  ADD CONSTRAINT `outcommig_mail_ibfk_1` FOREIGN KEY (`Fk_Letter`) REFERENCES `letter_package` (`Id_Letter_Package`);

--
-- Constraints der Tabelle `post_center_delivery`
--
ALTER TABLE `post_center_delivery`
  ADD CONSTRAINT `post_center_delivery_ibfk_1` FOREIGN KEY (`Fk_Post_Center`) REFERENCES `post_center` (`Id_Post_Center`),
  ADD CONSTRAINT `post_center_delivery_ibfk_2` FOREIGN KEY (`Fk_Post_Office`) REFERENCES `post_office` (`Id_Post_Office`),
  ADD CONSTRAINT `post_center_delivery_ibfk_3` FOREIGN KEY (`Fk_Delivery_Office`) REFERENCES `deliver_office` (`Id_Delivery_Office`),
  ADD CONSTRAINT `post_center_delivery_ibfk_4` FOREIGN KEY (`Fk_Letter`) REFERENCES `letter_package` (`Id_Letter_Package`);

--
-- Constraints der Tabelle `post_office`
--
ALTER TABLE `post_office`
  ADD CONSTRAINT `post_office_ibfk_1` FOREIGN KEY (`FK_Incomming_Mail`) REFERENCES `incomming_mail` (`Id_Incomming_Mail`),
  ADD CONSTRAINT `post_office_ibfk_2` FOREIGN KEY (`Fk_Mailbox`) REFERENCES `mailbox` (`Id_Mailbox`),
  ADD CONSTRAINT `post_office_ibfk_3` FOREIGN KEY (`Fk_Post_Partner`) REFERENCES `post_partner` (`Id_Post_Partner`);

--
-- Constraints der Tabelle `to_deliver`
--
ALTER TABLE `to_deliver`
  ADD CONSTRAINT `to_deliver_ibfk_1` FOREIGN KEY (`Fk_Outcomming_Mail`) REFERENCES `outcommig_mail` (`Id_Outcomming_Mail`),
  ADD CONSTRAINT `to_deliver_ibfk_2` FOREIGN KEY (`Fk_Delivery_Office`) REFERENCES `deliver_office` (`Id_Delivery_Office`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
